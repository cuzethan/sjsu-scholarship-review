"""
prompt.py — shared SJSU General prompt + rubric path (Phase 1).

ONE prompt-building path, ONE rubric file (sjsu_general_rubric.md). No
per-year, no per-department branching. Used by the scoring Lambda; the
evaluation harness points at the same rubric content.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

RUBRIC_PATH = Path(__file__).resolve().parent / "sjsu_general_rubric.md"

# Strict output schema (also enforced by validate()).
SCHEMA_INSTRUCTIONS = """
Return ONLY a single JSON object (no prose, no markdown fences) shaped exactly:

{
  "criterion_scores": [
    { "criterion": "string  // rubric category name",
      "score": 0,           // number within that category's scale
      "reasoning": "string" }
  ],
  "weighted_total": 0,      // sum of criterion scores (max 15)
  "reasoning_summary": "string  // 1-2 sentence overall justification"
}

Rules:
- One entry per rubric category (5 total).
- Score only from provided application content; do not invent facts.
- All strings MUST be properly JSON-escaped: use \\n for newlines, \\" for quotes, \\\\ for backslashes.
- Return ONLY the JSON object.
"""


@lru_cache(maxsize=1)
def load_rubric() -> str:
    return RUBRIC_PATH.read_text(encoding="utf-8")


def build_system_prompt() -> str:
    """Shared SJSU General system prompt = rubric + strict schema instructions."""
    return load_rubric() + "\n\n" + SCHEMA_INSTRUCTIONS


def build_user_message(app: dict) -> str:
    """Application content only (no human scores)."""
    lines = []
    if app.get("gpa"):
        lines.append(f"GPA: {app['gpa']}")
    if app.get("major"):
        lines.append(f"Major: {app['major']}")
    if app.get("academic_level"):
        lines.append(f"Academic Level: {app['academic_level']}")
    if app.get("academic_program"):
        lines.append(f"Academic Program: {app['academic_program']}")
    lines.append("\n--- Application Essays ---\n")
    for qa in app.get("qa_pairs", []):
        lines.append(f"Question [{qa.get('question_id','?')}]: {qa.get('question','')}")
        lines.append(f"Answer: {qa.get('answer','')}\n")
    return "\n".join(lines)


def extract_json(text: str) -> dict:
    """Pull a JSON object out of a model response (strips markdown fences).
    Attempts repair of common LLM JSON errors before giving up."""
    text = (text or "").strip()
    fence = re.search(r'```(?:json)?\s*(\{.*\})\s*```', text, re.DOTALL)
    if fence:
        text = fence.group(1)
    else:
        brace = re.search(r'(\{.*\})', text, re.DOTALL)
        if brace:
            text = brace.group(1)

    # First try: parse as-is
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Repair attempt: fix common issues
    repaired = text
    # Fix unescaped newlines inside strings
    repaired = re.sub(r'(?<!\\)\n', '\\n', repaired)
    # Fix trailing commas before } or ]
    repaired = re.sub(r',\s*([}\]])', r'\1', repaired)

    try:
        return json.loads(repaired)
    except json.JSONDecodeError:
        pass

    # Last resort: extract criterion_scores and rebuild
    cs_match = re.search(r'"criterion_scores"\s*:\s*(\[.*?\])\s*,', repaired, re.DOTALL)
    wt_match = re.search(r'"weighted_total"\s*:\s*([\d.]+)', repaired)
    if cs_match:
        try:
            cs = json.loads(cs_match.group(1))
            wt = float(wt_match.group(1)) if wt_match else 0
            return {
                "criterion_scores": cs,
                "weighted_total": wt,
                "reasoning_summary": "JSON repaired - partial parse",
            }
        except json.JSONDecodeError:
            pass

    # Give up - raise the original error
    return json.loads(text)


# Weights for computing final score out of 100 (SJSU General only — Phase 1)
WEIGHTS = {
    "Extracurricular Activities":   {"max": 1, "weight": 10},
    "Career Goals Essay":           {"max": 4, "weight": 40},
    "Challenge Essay":              {"max": 4, "weight": 30},
    "Initiative & Self-Motivation": {"max": 3, "weight": 10},
    "Creativity":                   {"max": 3, "weight": 10},
}


def calculate_final_score(criterion_scores: list) -> float:
    """Compute weighted score out of 100 from raw criterion scores."""
    total = 0.0
    for cs in criterion_scores:
        w = WEIGHTS.get(cs["criterion"])
        if w and w["max"] > 0:
            total += (cs["score"] / w["max"]) * w["weight"]
    return round(total, 2)


class SchemaError(ValueError):
    pass


def validate(obj) -> dict:
    """Validate a scoring response against the strict schema."""
    if not isinstance(obj, dict):
        raise SchemaError("top-level must be an object")
    cs = obj.get("criterion_scores")
    if not isinstance(cs, list) or not cs:
        raise SchemaError("criterion_scores must be a non-empty list")
    for i, c in enumerate(cs):
        if not isinstance(c, dict):
            raise SchemaError(f"criterion_scores[{i}] must be an object")
        if not isinstance(c.get("criterion"), str) or not c["criterion"].strip():
            raise SchemaError(f"criterion_scores[{i}].criterion must be a non-empty string")
        if isinstance(c.get("score"), bool) or not isinstance(c.get("score"), (int, float)):
            raise SchemaError(f"criterion_scores[{i}].score must be a number")
        if not isinstance(c.get("reasoning"), str):
            raise SchemaError(f"criterion_scores[{i}].reasoning must be a string")
    if isinstance(obj.get("weighted_total"), bool) or not isinstance(obj.get("weighted_total"), (int, float)):
        raise SchemaError("weighted_total must be a number")
    return obj
